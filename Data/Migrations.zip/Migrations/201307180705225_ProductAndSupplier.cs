namespace Data.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    public partial class ProductAndSupplier : DbMigration
    {
        public override void Up()
        {

            CreateTable(
                "dbo.Supplier",
                c => new
                {
                    SupplierId = c.Int(nullable: false, identity: true),
                    Name = c.String(nullable: false),
                    CreatedDate = c.DateTime(nullable: false),
                })
                .PrimaryKey(t => t.SupplierId);

            CreateTable(
                "dbo.Product",
                c => new
                {
                    ProductId = c.Int(nullable: false, identity: true),
                    Name = c.String(nullable: false),
                    CreatedDate = c.DateTime(nullable: false),
                    SupplierId = c.Int(nullable: false),
                })
                .PrimaryKey(t => t.ProductId)
                .ForeignKey("dbo.Supplier", t => t.SupplierId, cascadeDelete: true);

            CreateIndex("dbo.Product", "SupplierId");

            //add initial data to DB
            Sql("SET IDENTITY_INSERT [dbo].[Supplier] ON");
            Sql("INSERT[dbo].[Supplier] ([SupplierId], [Name], [CreatedDate]) VALUES(1, N'First supplier', CAST(N'2013-07-23 12:23:26.643' AS DateTime))");
            Sql("INSERT[dbo].[Supplier] ([SupplierId], [Name], [CreatedDate]) VALUES(2, N'Second', CAST(N'2013-07-23 12:23:35.000' AS DateTime))");
            Sql("INSERT[dbo].[Supplier] ([SupplierId], [Name], [CreatedDate]) VALUES(3, N'Third', CAST(N'2013-07-23 12:23:43.800' AS DateTime))");
            Sql("SET IDENTITY_INSERT[dbo].[Supplier] OFF");
            Sql("SET IDENTITY_INSERT[dbo].[Product] ON");
            Sql("INSERT[dbo].[Product] ([ProductId], [Name], [CreatedDate], [SupplierId]) VALUES(1, N'Product 1', CAST(N'2013-07-23 12:23:59.287' AS DateTime), 1)");
            Sql("INSERT[dbo].[Product] ([ProductId], [Name], [CreatedDate], [SupplierId]) VALUES(2, N'Product 2', CAST(N'2013-07-23 12:24:06.897' AS DateTime), 2)");
            Sql("INSERT[dbo].[Product] ([ProductId], [Name], [CreatedDate], [SupplierId]) VALUES(3, N'Product 3', CAST(N'2013-07-23 12:24:12.630' AS DateTime), 2)");
            Sql("SET IDENTITY_INSERT[dbo].[Product] OFF");
        }

        public override void Down()
        {
            DropIndex("dbo.Product", new[] { "SupplierId" });
            DropForeignKey("dbo.Product", "SupplierId", "dbo.Supplier");
            DropTable("dbo.Supplier");
            DropTable("dbo.Product");
        }
    }
}
